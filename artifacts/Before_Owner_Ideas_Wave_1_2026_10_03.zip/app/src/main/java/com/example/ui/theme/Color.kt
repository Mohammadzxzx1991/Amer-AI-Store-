package com.example.ui.theme

import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.geometry.Offset

// CompositionLocal to track if dark mode is active (defined in Theme.kt)

// Eye-Catching Ultra-Vibrant Color Palettes (Luminous Aurora, Electric Neon, 24K Gold, Sakura Blossom)
val SlateDarkBg: Color
    @Composable
    @ReadOnlyComposable
    get() {
        val isDark = LocalIsDark.current
        return when (LocalAppThemeStyle.current) {
            "gold" -> if (isDark) Color(0xFF0B132B) else Color(0xFFFFFBEB)
            "neon" -> if (isDark) Color(0xFF0C071E) else Color(0xFFFAF5FF)
            "sakura" -> if (isDark) Color(0xFF1A0C16) else Color(0xFFFFF1F2)
            "minimal" -> if (isDark) Color(0xFF0A0F1D) else Color(0xFFF8FAFC)
            else -> if (isDark) Color(0xFF080D1A) else Color(0xFFF6FBF7) // Aurora Midnight Obsidian
        }
    }

val CardDarkBg: Color
    @Composable
    @ReadOnlyComposable
    get() {
        val isDark = LocalIsDark.current
        return when (LocalAppThemeStyle.current) {
            "gold" -> if (isDark) Color(0xFF14213D) else Color(0xFFFFFFFF)
            "neon" -> if (isDark) Color(0xFF191038) else Color(0xFFFFFFFF)
            "sakura" -> if (isDark) Color(0xFF2E1528) else Color(0xFFFFFFFF)
            "minimal" -> if (isDark) Color(0xFF131B2E) else Color(0xFFFFFFFF)
            else -> if (isDark) Color(0xFF0F1B2B) else Color(0xFFFFFFFF) // High-contrast Glassy Midnight Card
        }
    }

val PrimaryCyan: Color
    @Composable
    @ReadOnlyComposable
    get() {
        val isDark = LocalIsDark.current
        return when (LocalAppThemeStyle.current) {
            "gold" -> if (isDark) Color(0xFFFFB703) else Color(0xFFF59E0B) // Radiant Gold
            "neon" -> if (isDark) Color(0xFFFF007F) else Color(0xFFE11D48) // Hyper Hot Pink
            "sakura" -> if (isDark) Color(0xFFFF4081) else Color(0xFFF43F5E) // Vivid Blossom
            "minimal" -> if (isDark) Color(0xFF38BDF8) else Color(0xFF0284C7) // Sky Sapphire
            else -> if (isDark) Color(0xFF00F5A0) else Color(0xFF00C853) // Electric Aurora Mint / Ultra Emerald
        }
    }

val SecondaryMint: Color
    @Composable
    @ReadOnlyComposable
    get() {
        val isDark = LocalIsDark.current
        return when (LocalAppThemeStyle.current) {
            "gold" -> if (isDark) Color(0xFFFFD166) else Color(0xFFFFB703)
            "neon" -> if (isDark) Color(0xFF00F0FF) else Color(0xFF06B6D4) // Electric Cyan
            "sakura" -> if (isDark) Color(0xFFFF758F) else Color(0xFFFF4D6D)
            "minimal" -> if (isDark) Color(0xFF818CF8) else Color(0xFF6366F1)
            else -> if (isDark) Color(0xFF00E5FF) else Color(0xFF00B4D8) // Luminous Cyan
        }
    }

val HeaderBlue: Color
    @Composable
    @ReadOnlyComposable
    get() = PrimaryCyan

val AccentCoral: Color
    @Composable
    @ReadOnlyComposable
    get() = Color(0xFFFF3366) // Vibrant Neon Coral

val WarmAmbar: Color
    @Composable
    @ReadOnlyComposable
    get() = Color(0xFFFFB703) // Radiant Sun Gold

val SoftGrayText: Color
    @Composable
    @ReadOnlyComposable
    get() = if (LocalIsDark.current) Color(0xFF94A3B8) else Color(0xFF64748B)

val PolarLight: Color
    @Composable
    @ReadOnlyComposable
    get() {
        val isDark = LocalIsDark.current
        return when (LocalAppThemeStyle.current) {
            "gold" -> if (isDark) Color(0xFFFFFBEB) else Color(0xFF0B132B)
            "neon" -> if (isDark) Color(0xFFFAF5FF) else Color(0xFF0C071E)
            "sakura" -> if (isDark) Color(0xFFFFF1F2) else Color(0xFF1A0C16)
            "minimal" -> if (isDark) Color(0xFFF8FAFC) else Color(0xFF0A0F1D)
            else -> if (isDark) Color(0xFFF8FAFC) else Color(0xFF0F172A)
        }
    }

// Eye-Catching Accent Palette Constants
val ElectricMint = Color(0xFF00F5A0)
val ElectricCyan = Color(0xFF00E5FF)
val NeonPink = Color(0xFFFF007F)
val SunGold = Color(0xFFFFB703)
val NeonCoral = Color(0xFFFF3366)
val ElectricViolet = Color(0xFFA855F7)

val ButtonGlowWhite: Color = Color(0xFFFFFFFF)

val ButtonGlowShadow: Shadow
    @Composable
    @ReadOnlyComposable
    get() = if (!LocalIsDark.current) {
        Shadow(
            color = Color(0xFFFFFFFF),
            offset = Offset(0f, 0f),
            blurRadius = 16f
        )
    } else {
        Shadow(
            color = Color(0x8800F5A0), // Luminous Neon Mint Aura Shadow
            offset = Offset(0f, 0f),
            blurRadius = 12f
        )
    }

val Purple80 = Color(0xFF00F5A0)
val PurpleGrey80 = Color(0xFF00E5FF)
val Pink80 = Color(0xFFFF3366)

val Purple40 = Color(0xFF00C853)
val PurpleGrey40 = Color(0xFFF9FAFB)
val Pink40 = Color(0xFFFF2E63)
