package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.*
import com.example.ui.MarketViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var db: AppDatabase
    private lateinit var viewModel: MarketViewModel

    @Before
    fun setUp() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
            
        viewModel = MarketViewModel(
            db.userDao(),
            db.productDao(),
            db.savedProductDao(),
            db.orderDao(),
            db.chatReportDao(),
            db.cartItemDao(),
            db.bankCardDao(),
            db.searchQueryDao(),
            db.familyShoppingListDao(),
            db.storedOrganicItemDao(),
            context.getSharedPreferences("test_prefs", Context.MODE_PRIVATE),
            db.cachedSearchResultDao(),
            db.cachedPriceComparisonDao()
        )
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun testViewModelInitialization() {
        assertNotNull(viewModel)
    }

    @Test
    fun testSearchHistoryFlowAndStateTransitions() = runBlocking {
        // Assert initial state is empty
        var recentSearches = viewModel.searchHistory.value
        assertEquals(0, recentSearches.size)

        // Add search query
        viewModel.addToSearchHistory("Product Lookup", "Organic Milk")
        
        recentSearches = viewModel.searchHistory.value
        assertEquals(1, recentSearches.size)
        assertEquals("Organic Milk", recentSearches[0].query)

        // Clear search history
        viewModel.clearSearchHistory()
        recentSearches = viewModel.searchHistory.value
        assertEquals(0, recentSearches.size)
    }

    @Test
    fun testRejectedLoginDoesNotCreateAccount() = runBlocking {
        val initialUsers = db.userDao().getAllUsers().first()
        assertEquals(0, initialUsers.size)

        val result = viewModel.login("unregistered_user@example.com", "WrongPassword123!")
        org.junit.Assert.assertFalse("Login must be rejected", result)

        val usersAfter = db.userDao().getAllUsers().first()
        assertEquals("No user account should be auto-created on rejected login", 0, usersAfter.size)
        org.junit.Assert.assertNull(viewModel.currentUser.value)
    }

    @Test
    fun testNoHardcodedPrivilegedLogin() = runBlocking {
        val result1 = viewModel.login("zxzx.Mohammad91@gmail.com", "MoAn320222m@")
        val result2 = viewModel.login("admin", "MoAn320222m@")

        org.junit.Assert.assertFalse("Former admin email must not grant access", result1)
        org.junit.Assert.assertFalse("Admin username must not grant access", result2)
        org.junit.Assert.assertNotEquals("Admin", viewModel.currentRole.value)
        org.junit.Assert.assertNull(viewModel.currentUser.value)
    }

    @Test
    fun testMissingFirebaseConfigFailsClosed() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val initialized = MainApplication.ensureFirebaseInitialized(context)
        org.junit.Assert.assertFalse("Firebase without valid credentials must not report configured", initialized)
        org.junit.Assert.assertFalse(MainApplication.isFirebaseConfigured)
        org.junit.Assert.assertFalse(viewModel.isFirebaseOnlineAvailable())

        val loginResult = viewModel.login("user@domain.com", "anyPassword123")
        org.junit.Assert.assertFalse("Authentication must fail closed when Firebase is unconfigured", loginResult)
        org.junit.Assert.assertNotNull("authError must be set when offline", viewModel.authError.value)
    }

    @Test
    fun testDatabaseInitializationIsNonDestructive() = runBlocking {
        val testUser = UserEntity(
            id = 1,
            name = "Persistent User",
            phoneNumber = "+1234567890",
            email = "persistent@example.com",
            role = "Customer",
            permissionGranted = true
        )
        db.userDao().insertUser(testUser)

        val retrieved = db.userDao().getUserByEmailOrPhone("persistent@example.com", "")
        assertNotNull(retrieved)
        assertEquals("Persistent User", retrieved?.name)

        org.junit.Assert.assertTrue(AppDatabase.ALL_MIGRATIONS.isNotEmpty())

        val users = db.userDao().getAllUsers().first()
        assertEquals(1, users.size)
        assertEquals("persistent@example.com", users[0].email)
    }
}
