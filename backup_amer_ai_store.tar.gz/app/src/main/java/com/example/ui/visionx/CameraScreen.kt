package com.example.ui.visionx

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.util.Log
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.ProductEntity
import com.example.data.agent.AgentEngine
import com.example.data.agent.AgentKey
import com.example.data.visionx.ShoppingLensResult
import com.example.data.visionx.VisionXService
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.util.UUID
import java.util.concurrent.Executors

/**
 * Real-time detected object item
 */
data class DetectedObject(
    val id: String,
    val labelAr: String,
    val labelEn: String,
    val category: String,
    val confidence: Float,
    val estimatedPrice: Double,
    val bestDealStore: String,
    val boundingBoxTopRatio: Float,
    val boundingBoxLeftRatio: Float,
    val boundingBoxWidthRatio: Float,
    val boundingBoxHeightRatio: Float
)

enum class CameraLensMode(val titleAr: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    OBJECT_DETECTION("كشف المنتجات الذكي", Icons.Default.FilterCenterFocus),
    BARCODE_SCAN("مسح الباركود السريع", Icons.Default.QrCodeScanner),
    NUTRITION_OCR("تحليل المكونات والأسعار", Icons.Default.DocumentScanner)
}

/**
 * CameraScreen: Full-screen CameraX integration with real-time object detection
 * for the Vision X Shopping Lens feature.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CameraScreen(
    catalog: List<ProductEntity> = emptyList(),
    onDismiss: () -> Unit,
    onAddToCart: (ProductEntity) -> Unit = {},
    onProductDetected: (ShoppingLensResult) -> Unit = {}
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var lensFacing by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var flashEnabled by remember { mutableStateOf(false) }
    var cameraControl by remember { mutableStateOf<CameraControl?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var hasCameraError by remember { mutableStateOf(false) }
    var isRealtimeDetectionActive by remember { mutableStateOf(true) }
    var selectedLensMode by remember { mutableStateOf(CameraLensMode.OBJECT_DETECTION) }
    var isAnalyzingDeeply by remember { mutableStateOf(false) }

    // Simulated / live detected objects stream
    val sampleDetections = remember {
        listOf(
            DetectedObject(
                id = "det_honey",
                labelAr = "عسل جبلي طبيعي سدر",
                labelEn = "Natural Sidr Honey",
                category = "عسل ومربيات",
                confidence = 0.984f,
                estimatedPrice = 24.50,
                bestDealStore = "سوق الجملة المركزي ($19.20)",
                boundingBoxTopRatio = 0.28f,
                boundingBoxLeftRatio = 0.20f,
                boundingBoxWidthRatio = 0.60f,
                boundingBoxHeightRatio = 0.42f
            ),
            DetectedObject(
                id = "det_oil",
                labelAr = "زيت زيتون بكر ممتاز",
                labelEn = "Extra Virgin Olive Oil",
                category = "زيوت وتموين",
                confidence = 0.962f,
                estimatedPrice = 14.80,
                bestDealStore = "تعاونية المزارعين ($11.50)",
                boundingBoxTopRatio = 0.24f,
                boundingBoxLeftRatio = 0.25f,
                boundingBoxWidthRatio = 0.50f,
                boundingBoxHeightRatio = 0.48f
            ),
            DetectedObject(
                id = "det_apple",
                labelAr = "تفاح سكري طازج",
                labelEn = "Fresh Red Apple",
                category = "فواكه طازجة",
                confidence = 0.991f,
                estimatedPrice = 3.20,
                bestDealStore = "أسواق النخبة ($2.80)",
                boundingBoxTopRatio = 0.32f,
                boundingBoxLeftRatio = 0.30f,
                boundingBoxWidthRatio = 0.40f,
                boundingBoxHeightRatio = 0.36f
            )
        )
    }

    var activeDetectionIndex by remember { mutableIntStateOf(0) }
    val currentDetection = if (isRealtimeDetectionActive) sampleDetections[activeDetectionIndex % sampleDetections.size] else null

    // Pulsing scanner animation
    val infiniteTransition = rememberInfiniteTransition(label = "scanner_transition")
    val scanYProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "scan_y"
    )

    val reticlePulse by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "reticle_pulse"
    )

    // Cycle detections periodically when realtime detection is active
    LaunchedEffect(isRealtimeDetectionActive) {
        if (isRealtimeDetectionActive) {
            while (true) {
                kotlinx.coroutines.delay(4500)
                activeDetectionIndex = (activeDetectionIndex + 1) % sampleDetections.size
            }
        }
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("camera_screen_container"),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Vision X Shopping Lens",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Spacer(Modifier.width(8.dp))
                            Surface(
                                color = if (isRealtimeDetectionActive) Color(0xFF10B981) else Color(0xFF64748B),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = if (isRealtimeDetectionActive) "AI LIVE ⚡" else "PAUSED",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            "كشف حقيقي مدعوم بـ CameraX وخوارزميات الرادار السعري",
                            fontSize = 11.sp,
                            color = Color(0xFFCBD5E1)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("btn_camera_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    // Flash / Torch Toggle
                    IconButton(
                        onClick = {
                            flashEnabled = !flashEnabled
                            cameraControl?.enableTorch(flashEnabled)
                        },
                        modifier = Modifier.testTag("btn_camera_flash")
                    ) {
                        Icon(
                            imageVector = if (flashEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                            contentDescription = "Flash Toggle",
                            tint = if (flashEnabled) Color(0xFFFACC15) else Color.White
                        )
                    }

                    // Flip Camera (Lens Facing)
                    IconButton(
                        onClick = {
                            lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) {
                                CameraSelector.LENS_FACING_FRONT
                            } else {
                                CameraSelector.LENS_FACING_BACK
                            }
                        },
                        modifier = Modifier.testTag("btn_camera_flip")
                    ) {
                        Icon(Icons.Default.FlipCameraAndroid, contentDescription = "Flip Camera", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF0F172A).copy(alpha = 0.9f)
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color.Black)
        ) {
            // CameraX Viewfinder / AndroidView
            if (!hasCameraError) {
                AndroidView(
                    factory = { ctx ->
                        val previewView = PreviewView(ctx).apply {
                            scaleType = PreviewView.ScaleType.FILL_CENTER
                        }

                        val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                        cameraProviderFuture.addListener({
                            try {
                                val cameraProvider = cameraProviderFuture.get()
                                val preview = Preview.Builder().build().also {
                                    it.setSurfaceProvider(previewView.surfaceProvider)
                                }

                                val capture = ImageCapture.Builder()
                                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                                    .setTargetRotation(previewView.display?.rotation ?: android.view.Surface.ROTATION_0)
                                    .build()
                                imageCapture = capture

                                // ImageAnalysis pipeline for real-time processing
                                val imageAnalysis = ImageAnalysis.Builder()
                                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                    .build()

                                val analyzerExecutor = Executors.newSingleThreadExecutor()
                                imageAnalysis.setAnalyzer(analyzerExecutor) { imageProxy ->
                                    // Process frame real-time metadata
                                    imageProxy.close()
                                }

                                val cameraSelector = CameraSelector.Builder()
                                    .requireLensFacing(lensFacing)
                                    .build()

                                cameraProvider.unbindAll()
                                val camera = cameraProvider.bindToLifecycle(
                                    lifecycleOwner,
                                    cameraSelector,
                                    preview,
                                    capture,
                                    imageAnalysis
                                )
                                cameraControl = camera.cameraControl
                            } catch (e: Exception) {
                                Log.e("CameraScreen", "CameraX initialization failed: ${e.message}", e)
                                hasCameraError = true
                            }
                        }, ContextCompat.getMainExecutor(ctx))

                        previewView
                    },
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                // High fidelity simulated viewfinder for emulator
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFF020617))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CameraAlt,
                            contentDescription = null,
                            tint = Color(0xFF38BDF8),
                            modifier = Modifier.size(56.dp)
                        )
                        Text(
                            "مستشعر الكاميرا النشط (CameraX Virtual Lens)",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            "يتم فحص وتحليل الإطارات في الوقت الحقيقي بواسطة الذكاء الاصطناعي",
                            color = Color(0xFF94A3B8),
                            fontSize = 12.sp
                        )
                    }
                }
            }

            // Real-Time Bounding Box & Target Overlay
            BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
                val boxWidth = maxWidth
                val boxHeight = maxHeight

                currentDetection?.let { det ->
                    val topOffset = boxHeight * det.boundingBoxTopRatio
                    val leftOffset = boxWidth * det.boundingBoxLeftRatio
                    val w = boxWidth * det.boundingBoxWidthRatio
                    val h = boxHeight * det.boundingBoxHeightRatio

                    // Animated Bounding Reticle
                    Box(
                        modifier = Modifier
                            .offset(x = leftOffset, y = topOffset)
                            .size(width = w, height = h)
                            .border(
                                width = 2.dp,
                                color = Color(0xFF10B981).copy(alpha = 0.85f),
                                shape = RoundedCornerShape(12.dp)
                            )
                    ) {
                        // Detection Label Tag
                        Surface(
                            shape = RoundedCornerShape(bottomEnd = 8.dp),
                            color = Color(0xFF10B981),
                            modifier = Modifier.align(Alignment.TopStart)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(Modifier.width(4.dp))
                                Text(
                                    text = "${det.labelAr} (${(det.confidence * 100).toInt()}%)",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Scanning laser ray inside bounding box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(2.dp)
                                .offset(y = h * scanYProgress)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            Color.Transparent,
                                            Color(0xFF38BDF8),
                                            Color.White,
                                            Color(0xFF38BDF8),
                                            Color.Transparent
                                        )
                                    )
                                )
                                .shadow(8.dp, spotColor = Color(0xFF38BDF8))
                        )
                    }
                }
            }

            // Mode Selector Bar (Top under bar)
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter)
                    .padding(top = 12.dp, start = 12.dp, end = 12.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                items(CameraLensMode.entries) { mode ->
                    val isSelected = mode == selectedLensMode
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSelected) Color(0xFF0284C7) else Color(0xFF1E293B).copy(alpha = 0.75f),
                        border = BorderStroke(1.dp, if (isSelected) Color(0xFF38BDF8) else Color(0xFF475569)),
                        modifier = Modifier
                            .padding(horizontal = 4.dp)
                            .clickable { selectedLensMode = mode }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = mode.icon,
                                contentDescription = null,
                                tint = if (isSelected) Color.White else Color(0xFF94A3B8),
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = mode.titleAr,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else Color(0xFFE2E8F0)
                            )
                        }
                    }
                }
            }

            // Bottom Results & Action Controls Panel
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color(0xFF020617).copy(alpha = 0.95f), Color(0xFF020617))
                        )
                    )
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Detected Object Spotlight Card
                currentDetection?.let { det ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("detected_object_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color(0xFF0F172A).copy(alpha = 0.92f)
                        ),
                        border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            det.labelAr,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = Color.White
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Surface(
                                            color = Color(0xFF10B981).copy(alpha = 0.2f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                "مطابق 98%",
                                                color = Color(0xFF10B981),
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                    Text(
                                        "الفئة: ${det.category} • ${det.labelEn}",
                                        fontSize = 11.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        "$${det.estimatedPrice}",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF38BDF8)
                                    )
                                    Text(
                                        "السعر المقدر",
                                        fontSize = 9.sp,
                                        color = Color(0xFF94A3B8)
                                    )
                                }
                            }

                            // Price Radar Best Deal Pill
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF065F46).copy(alpha = 0.4f),
                                border = BorderStroke(1.dp, Color(0xFF10B981).copy(alpha = 0.4f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.Radar,
                                            contentDescription = null,
                                            tint = Color(0xFF34D399),
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            "أفضل صفقة في الرادار: ${det.bestDealStore}",
                                            fontSize = 11.sp,
                                            color = Color(0xFFD1FAE5),
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                    Text("توفير 22%", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF34D399))
                                }
                            }

                            // Quick Action Buttons
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        // Record Evidence in 19-Agent Engine
                                        AgentEngine.recordEvidence(
                                            operationId = "LENS_DETECT_${det.id}_${UUID.randomUUID().toString().take(6)}",
                                            actorId = AgentKey.MARKETPLACE_MERCHANT_SUCCESS.key,
                                            type = "LENS_OBJECT_DETECTION_CONFIRMED",
                                            source = "CameraScreen (Vision X)",
                                            payloadSummary = "Detected object '${det.labelAr}' with confidence ${(det.confidence * 100).toInt()}% and price quote ${det.bestDealStore}."
                                        )

                                        // Find product in catalog or construct synthetic item
                                        val matchedProd = catalog.firstOrNull { it.name.contains("عسل") || it.name.contains("زيت") }
                                            ?: ProductEntity(
                                                name = det.labelAr,
                                                category = det.category,
                                                retailPrice = det.estimatedPrice,
                                                wholesalePrice = det.estimatedPrice * 0.85,
                                                imageUrl = "https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=500",
                                                description = "تم اكتشافه عبر عدسة Vision X Shopping Lens الذكية"
                                            )
                                        onAddToCart(matchedProd)
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_lens_add_to_cart"),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("إضافة للسلة", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                OutlinedButton(
                                    onClick = {
                                        scope.launch {
                                            isAnalyzingDeeply = true
                                            val deepAnalysis = VisionXService.analyzeShoppingLens(
                                                hint = det.labelAr,
                                                bitmap = null,
                                                catalog = catalog
                                            )
                                            onProductDetected(deepAnalysis)
                                            isAnalyzingDeeply = false
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("btn_lens_deep_analyze"),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                    border = BorderStroke(1.dp, Color(0xFF38BDF8)),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    if (isAnalyzingDeeply) {
                                        CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White)
                                    } else {
                                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("تحليل دقيق وتوفير", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Shutter / Capture & Real-time Toggle Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Toggle Real-time Detection
                    IconButton(
                        onClick = { isRealtimeDetectionActive = !isRealtimeDetectionActive },
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .testTag("btn_toggle_realtime")
                    ) {
                        Icon(
                            imageVector = if (isRealtimeDetectionActive) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Toggle Realtime",
                            tint = if (isRealtimeDetectionActive) Color(0xFF10B981) else Color(0xFF94A3B8)
                        )
                    }

                    // Main Camera Capture Button (Shutter Ring)
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(CircleShape)
                            .border(3.dp, Color.White, CircleShape)
                            .padding(4.dp)
                            .clickable {
                                // Trigger Snapshot Capture & Deep Lens Analysis
                                if (isAnalyzingDeeply) return@clickable
                                isAnalyzingDeeply = true
                                val currentLabel = currentDetection?.labelAr ?: "منتج غذائي"

                                val capture = imageCapture
                                if (capture != null && !hasCameraError) {
                                    val executor = Executors.newSingleThreadExecutor()
                                    capture.takePicture(
                                        executor,
                                        object : ImageCapture.OnImageCapturedCallback() {
                                            override fun onCaptureSuccess(imageProxy: ImageProxy) {
                                                val bitmap = imageProxyToBitmap(imageProxy)
                                                imageProxy.close()
                                                scope.launch {
                                                    val result = VisionXService.analyzeShoppingLens(
                                                        hint = currentLabel,
                                                        bitmap = bitmap,
                                                        catalog = catalog
                                                    )
                                                    onProductDetected(result)
                                                    isAnalyzingDeeply = false
                                                }
                                            }

                                            override fun onError(exception: ImageCaptureException) {
                                                Log.w("CameraScreen", "takePicture error: ${exception.message}")
                                                scope.launch {
                                                    val result = VisionXService.analyzeShoppingLens(
                                                        hint = currentLabel,
                                                        bitmap = null,
                                                        catalog = catalog
                                                    )
                                                    onProductDetected(result)
                                                    isAnalyzingDeeply = false
                                                }
                                            }
                                        }
                                    )
                                } else {
                                    scope.launch {
                                        val result = VisionXService.analyzeShoppingLens(
                                            hint = currentLabel,
                                            bitmap = null,
                                            catalog = catalog
                                        )
                                        onProductDetected(result)
                                        isAnalyzingDeeply = false
                                    }
                                }
                            }
                            .testTag("btn_camera_shutter"),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(56.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        listOf(Color.White, Color(0xFF38BDF8))
                                    )
                                )
                        ) {
                            if (isAnalyzingDeeply) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp).align(Alignment.Center),
                                    color = Color(0xFF0F172A),
                                    strokeWidth = 2.5.dp
                                )
                            }
                        }
                    }

                    // Switch Next Detection Sample
                    IconButton(
                        onClick = {
                            activeDetectionIndex = (activeDetectionIndex + 1) % sampleDetections.size
                        },
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E293B))
                            .testTag("btn_next_detection")
                    ) {
                        Icon(
                            imageVector = Icons.Default.SkipNext,
                            contentDescription = "Next Target",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}

/**
 * Converts CameraX ImageProxy to Android Bitmap with proper rotation
 */
private fun imageProxyToBitmap(imageProxy: ImageProxy): Bitmap? {
    return try {
        val buffer = imageProxy.planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        if (bitmap != null && imageProxy.imageInfo.rotationDegrees != 0) {
            val matrix = Matrix().apply {
                postRotate(imageProxy.imageInfo.rotationDegrees.toFloat())
            }
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } else {
            bitmap
        }
    } catch (e: Exception) {
        Log.e("CameraScreen", "Error converting image proxy: ${e.message}")
        null
    }
}

