package com.example.ui.visionx

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.CartItemEntity
import com.example.data.OrderEntity
import com.example.data.ProductEntity
import com.example.ui.TrendingProduct
import com.example.data.visionx.*
import kotlinx.coroutines.launch

/**
 * Living Store: Command Orb Floating Action Button & Radial Launcher
 */
@Composable
fun CommandOrb(
    onOpenLens: () -> Unit,
    onOpenPriceRadar: () -> Unit,
    onOpenBasketOptimizer: () -> Unit,
    onOpenShoppingMission: () -> Unit,
    onOpenReceiptScan: () -> Unit,
    onOpenCreativeStudio: () -> Unit,
    onOpenAgentHub: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }

    Box(modifier = modifier, contentAlignment = Alignment.BottomEnd) {
        // Expanded Quick Menu
        AnimatedVisibility(
            visible = isExpanded,
            enter = fadeIn() + scaleIn(initialScale = 0.8f),
            exit = fadeOut() + scaleOut(targetScale = 0.8f)
        ) {
            Surface(
                modifier = Modifier
                    .padding(bottom = 72.dp, end = 4.dp)
                    .width(260.dp),
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceColorAtElevation(6.dp),
                tonalElevation = 8.dp,
                shadowElevation = 12.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        "Command Orb • مركز العمليات الذكي",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    CommandOrbItem(
                        icon = Icons.Default.CameraAlt,
                        title = "عدسة الشراء الذكية (Lens)",
                        subtitle = "تصوير ومطابقة المنتج والأسعار",
                        tint = Color(0xFF3B82F6),
                        onClick = { isExpanded = false; onOpenLens() }
                    )

                    CommandOrbItem(
                        icon = Icons.Default.Radar,
                        title = "رادار الأسعار (Price Radar)",
                        subtitle = "مقارنة فورية بين المتاجر وتنبيهات",
                        tint = Color(0xFF10B981),
                        onClick = { isExpanded = false; onOpenPriceRadar() }
                    )

                    CommandOrbItem(
                        icon = Icons.Default.ShoppingBasket,
                        title = "محسن السلة (Basket Optimizer)",
                        subtitle = "أقصى توفير وأسرع توصيل",
                        tint = Color(0xFFF59E0B),
                        onClick = { isExpanded = false; onOpenBasketOptimizer() }
                    )

                    CommandOrbItem(
                        icon = Icons.Default.AutoAwesome,
                        title = "مهام الشراء بالذكاء الاصطناعي",
                        subtitle = "تخطيط العزائم والميزانيات آلياً",
                        tint = Color(0xFF8B5CF6),
                        onClick = { isExpanded = false; onOpenShoppingMission() }
                    )

                    CommandOrbItem(
                        icon = Icons.Default.ReceiptLong,
                        title = "تحليل الفواتير الذكي (Receipts)",
                        subtitle = "كشف الفروقات وطلب استرداد فوري",
                        tint = Color(0xFFEC4899),
                        onClick = { isExpanded = false; onOpenReceiptScan() }
                    )

                    CommandOrbItem(
                        icon = Icons.Default.Palette,
                        title = "استوديو الابتكار (Creative Studio)",
                        subtitle = "توليد تصاميم وإعلانات AR/EN",
                        tint = Color(0xFF06B6D4),
                        onClick = { isExpanded = false; onOpenCreativeStudio() }
                    )

                    CommandOrbItem(
                        icon = Icons.Default.Hub,
                        title = "منظومة الـ 19 وكيلاً (Agent OS)",
                        subtitle = "مراقبة وإدارة الحوكمة الذاتية",
                        tint = Color(0xFF6366F1),
                        onClick = { isExpanded = false; onOpenAgentHub() }
                    )
                }
            }
        }

        // Orb Trigger Button
        FloatingActionButton(
            onClick = { isExpanded = !isExpanded },
            modifier = Modifier
                .size(58.dp)
                .shadow(8.dp, CircleShape)
                .testTag("btn_command_orb"),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            shape = CircleShape
        ) {
            Icon(
                imageVector = if (isExpanded) Icons.Default.Close else Icons.Default.AutoAwesome,
                contentDescription = "Command Orb",
                modifier = Modifier.size(28.dp)
            )
        }
    }
}

@Composable
fun CommandOrbItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tint: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(tint.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
        }

        Spacer(Modifier.width(10.dp))

        Column {
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

/**
 * Universal Shopping Lens Dialog with CameraX Lifecycle & Gemini Product Recognition
 */
@Composable
fun ShoppingLensDialog(
    catalog: List<ProductEntity>,
    onDismiss: () -> Unit,
    onAddToCart: (ProductEntity) -> Unit
) {
    var isCameraMode by remember { mutableStateOf(true) }
    var searchHint by remember { mutableStateOf("عسل طبيعي عضوي") }
    var capturedBitmap by remember { mutableStateOf<android.graphics.Bitmap?>(null) }
    var lensResult by remember { mutableStateOf<ShoppingLensResult?>(null) }
    var isAnalyzing by remember { mutableStateOf(false) }
    var showFullScreenCamera by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    if (showFullScreenCamera) {
        Dialog(
            onDismissRequest = { showFullScreenCamera = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            CameraScreen(
                catalog = catalog,
                onDismiss = { showFullScreenCamera = false },
                onAddToCart = { product ->
                    onAddToCart(product)
                    showFullScreenCamera = false
                },
                onProductDetected = { result ->
                    lensResult = result
                    showFullScreenCamera = false
                }
            )
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(16.dp)
                    .verticalScroll(androidx.compose.foundation.rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null, tint = Color(0xFF3B82F6))
                        Spacer(Modifier.width(8.dp))
                        Text("عدسة الشراء الذكية (Shopping Lens)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }

                Text(
                    "تصوير ومطابقة المنتج بالذكاء الاصطناعي (Gemini & CameraX) والبحث في الكتالوج المعتمد.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Mode Selector Tabs (Camera vs Manual Query)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        .padding(2.dp)
                ) {
                    TabButton(
                        title = "كاميرا العدسة (CameraX)",
                        icon = Icons.Default.Camera,
                        selected = isCameraMode,
                        onClick = { isCameraMode = true },
                        modifier = Modifier.weight(1f)
                    )
                    TabButton(
                        title = "بحث يدوي",
                        icon = Icons.Default.Search,
                        selected = !isCameraMode,
                        onClick = { isCameraMode = false },
                        modifier = Modifier.weight(1f)
                    )
                }

                if (isCameraMode) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "مستشعر الكاميرا المباشر (CameraX)",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        FilledTonalButton(
                            onClick = { showFullScreenCamera = true },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.height(30.dp).testTag("btn_open_fullscreen_camera")
                        ) {
                            Icon(Icons.Default.Fullscreen, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("شاشة كاملة وكشف حي", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Live CameraX Viewfinder
                    ShoppingLensCameraXView(
                        onFrameCaptured = { bitmap ->
                            capturedBitmap = bitmap
                            scope.launch {
                                isAnalyzing = true
                                lensResult = VisionXService.analyzeShoppingLens(
                                    hint = searchHint,
                                    bitmap = bitmap,
                                    catalog = catalog
                                )
                                isAnalyzing = false
                            }
                        }
                    )
                } else {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = searchHint,
                            onValueChange = { searchHint = it },
                            label = { Text("اسم أو وصف المنتج") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Button(
                            onClick = {
                                scope.launch {
                                    isAnalyzing = true
                                    lensResult = VisionXService.analyzeShoppingLens(searchHint, null, catalog)
                                    isAnalyzing = false
                                }
                            },
                            modifier = Modifier.align(Alignment.CenterVertically)
                        ) {
                            Text("مسح")
                        }
                    }
                }

                if (isAnalyzing) {
                    Box(modifier = Modifier.fillMaxWidth().height(100.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            CircularProgressIndicator(modifier = Modifier.size(32.dp), strokeWidth = 3.dp)
                            Text("جاري تحليل الإطار ومطابقته بواسطة Gemini...", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                } else if (lensResult != null) {
                    val result = lensResult!!
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        ),
                        border = BorderStroke(1.dp, Color(0xFF3B82F6))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(result.detectedProductNameAr, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Surface(
                                    color = Color(0xFF10B981).copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        "دقة المطابقة: ${(result.confidenceScore * 100).toInt()}%",
                                        color = Color(0xFF10B981),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            Text("التصنيف: ${result.category}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("السعر التقديري بالكتالوج: $${result.estimatedMarketPrice}", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                            Text("أفضل متجر قريب: ${result.bestNearbyStore} (يبعد ${result.distanceKm} كم)", fontSize = 12.sp)

                            Surface(
                                color = Color(0xFF10B981).copy(alpha = 0.08f),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    "Evidence ID: ${result.evidenceId}",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF10B981),
                                    modifier = Modifier.padding(6.dp)
                                )
                            }
                        }
                    }

                    val matchedProduct = catalog.find { it.id in result.matchedProductIds }
                    if (matchedProduct != null) {
                        Button(
                            onClick = {
                                onAddToCart(matchedProduct)
                                onDismiss()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981))
                        ) {
                            Icon(Icons.Default.AddShoppingCart, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("إضافة المنتج المطابق (${matchedProduct.name}) إلى السلة")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TabButton(
    title: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
        shape = RoundedCornerShape(8.dp),
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(16.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                title,
                fontSize = 11.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                color = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

/**
 * Price Radar & Live Quotes Dialog
 */
@Composable
fun PriceRadarDialog(
    catalog: List<ProductEntity>,
    onDismiss: () -> Unit
) {
    val radarItems = remember(catalog) { VisionXService.getPriceRadarItems(catalog) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Radar, contentDescription = null, tint = Color(0xFF10B981))
                        Spacer(Modifier.width(8.dp))
                        Text("رادار الأسعار المباشر (Price Radar)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }

                Text(
                    "مقارنة حية لأسعار التجزئة والجملة بين المتاجر المسجلة والافتراضية مع التوثيق بالأدلة.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier.heightIn(max = 450.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(radarItems) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                            )
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(item.productNameAr, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(
                                        "السعر الحالي: $${item.currentRetailPrice}",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                item.quotes.forEach { quote ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                if (quote.isBestDeal) Color(0xFF10B981).copy(alpha = 0.1f) else Color.Transparent,
                                                RoundedCornerShape(6.dp)
                                            )
                                            .padding(6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = "${quote.providerName} (${quote.distanceKm} كم)",
                                                fontSize = 11.sp,
                                                fontWeight = if (quote.isBestDeal) FontWeight.Bold else FontWeight.Normal
                                            )
                                            Text(text = "المصدر: ${quote.source}", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "$${quote.price}",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (quote.isBestDeal) Color(0xFF10B981) else MaterialTheme.colorScheme.onSurface
                                            )
                                            if (quote.isBestDeal) {
                                                Text("أفضل سعر ⭐", fontSize = 9.sp, color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }

                                Text(
                                    "Evidence ID: ${item.evidenceId}",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                // FCM Push Notification Trigger for Price Radar
                                val context = androidx.compose.ui.platform.LocalContext.current
                                var isSubscribed by remember { mutableStateOf(false) }
                                var notifSentNotice by remember { mutableStateOf(false) }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    FilledTonalButton(
                                        onClick = {
                                            isSubscribed = !isSubscribed
                                            if (isSubscribed) {
                                                com.example.data.visionx.PriceRadarMessagingService.subscribeToProductPriceAlerts(item.productId)
                                            } else {
                                                com.example.data.visionx.PriceRadarMessagingService.unsubscribeFromProductPriceAlerts(item.productId)
                                            }
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (isSubscribed) Icons.Default.NotificationsActive else Icons.Default.Notifications,
                                            contentDescription = null,
                                            modifier = Modifier.size(14.dp),
                                            tint = if (isSubscribed) Color(0xFF10B981) else MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            text = if (isSubscribed) "تنبيه FCM مفعل 🔔" else "تتبع السعر (FCM)",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            val targetP = (item.currentRetailPrice * 0.85)
                                            com.example.data.visionx.PriceRadarMessagingService.showPriceRadarNotification(
                                                context = context,
                                                productId = item.productId,
                                                title = "🎯 رادار الأسعار: وصل السعر المستهدف!",
                                                body = "وصل سعر '${item.productNameAr}' إلى $${String.format("%.2f", targetP)} في أفضل متجر معتمد! اضغط للشراء.",
                                                productName = item.productNameAr,
                                                currentPrice = targetP
                                            )
                                            notifSentNotice = true
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(if (notifSentNotice) "تم إرسال الإشعار ✅" else "تجربة الإشعار", fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Smart Basket Optimizer Dialog powered by BasketOptimizerViewModel
 */
@Composable
fun BasketOptimizerDialog(
    cartItems: List<CartItemEntity>,
    onDismiss: () -> Unit,
    onApplyOptimization: (BasketOptimizationResult) -> Unit,
    wishlistProducts: List<TrendingProduct> = emptyList(),
    viewModel: BasketOptimizerViewModel = androidx.lifecycle.viewmodel.compose.viewModel()
) {
    val selectedObjective by viewModel.selectedObjective.collectAsState()
    val optimizationResult by viewModel.optimizationResult.collectAsState()
    val sourceComparisons by viewModel.sourceComparisons.collectAsState()
    val isOptimizing by viewModel.isOptimizing.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    var useWishlistSource by remember { mutableStateOf(wishlistProducts.isNotEmpty() && cartItems.isEmpty()) }

    LaunchedEffect(cartItems, wishlistProducts, useWishlistSource) {
        if (useWishlistSource && wishlistProducts.isNotEmpty()) {
            viewModel.optimizeWishlistBasket(wishlistProducts)
        } else {
            viewModel.optimizeBasket(cartItems)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(6.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ShoppingBasket, contentDescription = null, tint = Color(0xFFF59E0B))
                        Spacer(Modifier.width(8.dp))
                        Text("محسن السلة الذكي (Basket Optimizer)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }

                Text(
                    "مقارنة حية لأسعار السلة بين مصادر السوق (جملة، تجزئة، مزارع) وإعادة توزيع ذكية لتوفير أقصى مبلغ.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Sub-tabs: Optimized Splits vs Source Comparisons
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp))
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("خطة التوزيع الموفرة", fontSize = 12.sp, fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("مقارنة أسعار المصادر", fontSize = 12.sp, fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) }
                    )
                }

                // Source Switcher (Active Cart vs Wishlist)
                if (wishlistProducts.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                            .padding(2.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Surface(
                            onClick = {
                                useWishlistSource = false
                                viewModel.optimizeBasket(cartItems)
                            },
                            color = if (!useWishlistSource) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                "🛒 سلة الشراء الحالية (${cartItems.size})",
                                fontSize = 11.sp,
                                fontWeight = if (!useWishlistSource) FontWeight.Bold else FontWeight.Normal,
                                color = if (!useWishlistSource) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        }

                        Surface(
                            onClick = {
                                useWishlistSource = true
                                viewModel.optimizeWishlistBasket(wishlistProducts)
                            },
                            color = if (useWishlistSource) MaterialTheme.colorScheme.primary else Color.Transparent,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                "❤️ قائمة الأمنيات المحفوظة (${wishlistProducts.size})",
                                fontSize = 11.sp,
                                fontWeight = if (useWishlistSource) FontWeight.Bold else FontWeight.Normal,
                                color = if (useWishlistSource) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        }
                    }
                }

                // Objectives Chips
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(OptimizationObjective.entries) { obj ->
                        FilterChip(
                            selected = selectedObjective == obj,
                            onClick = {
                                if (useWishlistSource && wishlistProducts.isNotEmpty()) {
                                    viewModel.setObjectiveForWishlist(obj, wishlistProducts)
                                } else {
                                    viewModel.setObjective(obj, cartItems)
                                }
                            },
                            label = { Text(obj.labelAr, fontSize = 11.sp) }
                        )
                    }
                }

                if (isOptimizing) {
                    Box(modifier = Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(modifier = Modifier.size(32.dp))
                    }
                } else {
                    when (selectedTab) {
                        0 -> {
                            // Optimal Splits View
                            optimizationResult?.let { res ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                    ),
                                    border = BorderStroke(1.dp, Color(0xFFF59E0B))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column {
                                                Text("السعر الأصلي", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text("$${String.format("%.2f", res.originalTotal)}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            }
                                            Column {
                                                Text("السعر بعد التحسين", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text("$${String.format("%.2f", res.optimizedTotal)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                                            }
                                            Column {
                                                Text("إجمالي التوفير", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                Text("-$${String.format("%.2f", res.totalSavings)}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                                            }
                                        }

                                        Text("خطة التنفيذ: ${res.strategyExplanationAr}", fontSize = 11.sp)

                                        // Store splits preview
                                        res.storeSplits.forEach { split ->
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = MaterialTheme.colorScheme.surface,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(8.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column {
                                                        Text(split.storeName, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                        Text("${split.itemNames.size} عناصر • توصيل خلال ${split.etaMinutes} دقيقة", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                    }
                                                    Text("$${String.format("%.2f", split.subtotal + split.deliveryFee)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                                }
                                            }
                                        }

                                        Text(
                                            "Evidence ID: ${res.evidenceId}",
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        viewModel.applyOptimization {
                                            onApplyOptimization(res)
                                            onDismiss()
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("اعتماد وتطبيق خطة التوفير على السلة")
                                }
                            }
                        }
                        1 -> {
                            // Multi-Source Comparisons View
                            LazyColumn(
                                modifier = Modifier.heightIn(max = 280.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(sourceComparisons) { comp ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(
                                            containerColor = if (comp.isBestPrice) Color(0xFFECFDF5) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                        ),
                                        border = if (comp.isBestPrice) BorderStroke(1.dp, Color(0xFF10B981)) else null
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(comp.sourceNameAr, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                    if (comp.isBestPrice) {
                                                        Spacer(Modifier.width(4.dp))
                                                        Surface(color = Color(0xFF10B981), shape = RoundedCornerShape(4.dp)) {
                                                            Text("أفضل سعر", color = Color.White, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                                        }
                                                    }
                                                    if (comp.isFastest) {
                                                        Spacer(Modifier.width(4.dp))
                                                        Surface(color = Color(0xFF3B82F6), shape = RoundedCornerShape(4.dp)) {
                                                            Text("الأسرع", color = Color.White, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                                        }
                                                    }
                                                }
                                                Text("الفئة: ${comp.sourceCategory} • وصول: ${comp.etaMinutes} دقيقة", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                if (comp.savingsVsCurrent > 0) {
                                                    Text("وفر: $${String.format("%.2f", comp.savingsVsCurrent)}", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                                                }
                                            }
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text("$${String.format("%.2f", comp.totalCost)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                                Text("رسوم التوصيل: $${String.format("%.2f", comp.deliveryFee)}", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * AI Shopping Missions Dialog
 */
@Composable
fun ShoppingMissionDialog(
    catalog: List<ProductEntity>,
    onDismiss: () -> Unit,
    onAddMissionItemsToCart: (List<MissionItem>) -> Unit
) {
    var missionPrompt by remember { mutableStateOf("عزومة عشاء لـ 10 أشخاص بميزانية 70 دينار") }
    var budgetValue by remember { mutableDoubleStateOf(70.0) }
    var missionResult by remember { mutableStateOf<ShoppingMission?>(null) }

    LaunchedEffect(missionPrompt, budgetValue) {
        missionResult = VisionXService.planShoppingMission(missionPrompt, budgetValue, catalog)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF8B5CF6))
                        Spacer(Modifier.width(8.dp))
                        Text("مهام الشراء بالذكاء الاصطناعي (Missions)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }

                Text(
                    "حدد هدفك وميزانيتك، وتقوم منظومة الوكلاء بحساب وتجميع كافة الاحتياجات كمسودة جاهزة.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = missionPrompt,
                    onValueChange = { missionPrompt = it },
                    label = { Text("الهدف الشرائي") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                missionResult?.let { mission ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("الميزانية المحددة: $${mission.targetBudget}", fontSize = 12.sp)
                                Text("الإجمالي المحسوب: $${String.format("%.2f", mission.calculatedTotal)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
                            }

                            Text("العناصر المقترحة (${mission.draftItems.size} أصناف):", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            mission.draftItems.forEach { item ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("• ${item.name} (${item.quantity}x)", fontSize = 11.sp)
                                    Text("$${item.totalPrice}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }

                            Spacer(Modifier.height(4.dp))
                            Text("رأي الوكلاء المعتمدين:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            mission.agentInsights.take(3).forEach { insight ->
                                Text("• ${insight.agentNameAr}: ${insight.insightTextAr}", fontSize = 10.sp)
                            }
                        }
                    }

                    Button(
                        onClick = {
                            onAddMissionItemsToCart(mission.draftItems)
                            onDismiss()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AddShoppingCart, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("اعتماد وإضافة مسودة المهمة للسلة")
                    }
                }
            }
        }
    }
}

/**
 * Receipt Intelligence Dialog
 */
@Composable
fun ReceiptIntelligenceDialog(
    onDismiss: () -> Unit,
    onSubmitClaim: (String) -> Unit
) {
    val scanResult = remember { VisionXService.scanReceiptIntelligence("", null) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = Color(0xFFEC4899))
                        Spacer(Modifier.width(8.dp))
                        Text("تحليل الفواتير الذكي (Receipts)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }

                Text(
                    "مطابقة بنود الفاتورة مع أسعار الكتالوج المعتمدة وكشف أي زيادة سعر أو تلاعب تلقائياً.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("المتجر: ${scanResult.merchantName}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("تاريخ الفاتورة: ${scanResult.purchaseTimestamp}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        scanResult.lineItems.forEach { item ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (item.hasDiscrepancy) Color(0xFFEF4444).copy(alpha = 0.1f) else Color.Transparent, RoundedCornerShape(4.dp))
                                    .padding(4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${item.itemName} (${item.quantity}x)", fontSize = 11.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("المحسوب: $${item.billedPrice}", fontSize = 11.sp, fontWeight = if (item.hasDiscrepancy) FontWeight.Bold else FontWeight.Normal, color = if (item.hasDiscrepancy) Color(0xFFEF4444) else MaterialTheme.colorScheme.onSurface)
                                    if (item.hasDiscrepancy) {
                                        Text("الأصل: $${item.expectedCatalogPrice}", fontSize = 10.sp, color = Color(0xFF10B981))
                                    }
                                }
                            }
                        }

                        if (scanResult.disputeDraftReady) {
                            Surface(
                                color = Color(0xFFEF4444).copy(alpha = 0.1f),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    scanResult.disputeRecommendationAr,
                                    fontSize = 11.sp,
                                    color = Color(0xFFEF4444),
                                    modifier = Modifier.padding(6.dp)
                                )
                            }
                        }
                    }
                }

                if (scanResult.disputeDraftReady) {
                    Button(
                        onClick = {
                            onSubmitClaim(scanResult.evidenceId)
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Gavel, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("تقديم طلب استرداد فوري مع الإثبات")
                    }
                }
            }
        }
    }
}

/**
 * Order Digital Twin Dialog
 */
@Composable
fun OrderDigitalTwinDialog(
    order: OrderEntity,
    onDismiss: () -> Unit
) {
    val twin = remember(order) { VisionXService.getOrderDigitalTwin(order) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocalShipping, contentDescription = null, tint = Color(0xFF3B82F6))
                        Spacer(Modifier.width(8.dp))
                        Text("التوأم الرقمي للطلب (Digital Twin)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }

                Text(
                    "الطلب #${twin.orderId}: ${twin.productName} (${twin.quantity}x) • السائق: ${twin.driverName}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Surface(
                    color = Color(0xFF3B82F6).copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("الحالة الحالية: ${twin.currentStage.titleAr}", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF3B82F6))
                        if (twin.etaMinutes > 0) {
                            Text("الوصول خلال: ${twin.etaMinutes} دقيقة", fontSize = 11.sp, color = Color(0xFF3B82F6))
                        }
                    }
                }

                Text("سجل الأحداث الموثق رقمياً بالأدلة:", fontSize = 11.sp, fontWeight = FontWeight.Bold)

                LazyColumn(
                    modifier = Modifier.heightIn(max = 280.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(twin.events) { ev ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(ev.stage.titleAr, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text(ev.noteAr, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("Ev: ${ev.evidenceId}", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF10B981))
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * AI Creative Studio Dialog with Ad Copy and AI Image Editor
 */
@Composable
fun CreativeStudioDialog(
    onDismiss: () -> Unit
) {
    var studioTab by remember { mutableIntStateOf(0) }
    var selectedType by remember { mutableStateOf(CreativeType.AD_COPY_AR) }
    var briefPrompt by remember { mutableStateOf("عسل طبيعي جبلي وزيت زيتون بكر فاخر") }
    var jobResult by remember { mutableStateOf<CreativeJob?>(null) }

    LaunchedEffect(selectedType, briefPrompt) {
        jobResult = VisionXService.createCreativeJob(selectedType, briefPrompt)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .padding(6.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Palette, contentDescription = null, tint = Color(0xFF06B6D4))
                        Spacer(Modifier.width(8.dp))
                        Text("استوديو الإبداع (Creative Studio)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                    IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, contentDescription = "Close") }
                }

                // Studio Mode Tabs
                TabRow(
                    selectedTabIndex = studioTab,
                    containerColor = MaterialTheme.colorScheme.surfaceContainer,
                    modifier = Modifier.clip(RoundedCornerShape(10.dp))
                ) {
                    Tab(
                        selected = studioTab == 0,
                        onClick = { studioTab = 0 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("محرر الصور الذكي", fontSize = 12.sp, fontWeight = if (studioTab == 0) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    )
                    Tab(
                        selected = studioTab == 1,
                        onClick = { studioTab = 1 },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.EditNote, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("الموجز الإعلاني", fontSize = 12.sp, fontWeight = if (studioTab == 1) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    )
                }

                when (studioTab) {
                    0 -> {
                        // AI Product Photo Editor Interface
                        AiProductImageEditor(
                            onEnhancedApplied = { prodName, evId ->
                                // Handled in component
                            }
                        )
                    }
                    1 -> {
                        // Ad Copy & Campaign Generation Interface
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(
                                "توليد محتوى ترويجي ثنائي اللغة AR/EN ومواد بصرية مع وثيقة الإثبات الرقمي.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                items(CreativeType.entries) { type ->
                                    FilterChip(
                                        selected = selectedType == type,
                                        onClick = { selectedType = type },
                                        label = { Text(type.titleAr, fontSize = 11.sp) }
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = briefPrompt,
                                onValueChange = { briefPrompt = it },
                                label = { Text("الموجز الإعلاني / تفاصيل المنتج") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            jobResult?.let { job ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                    )
                                ) {
                                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("المخرجات الإبداعية المعتمدة:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                        Text(job.generatedArtifact, fontSize = 12.sp)

                                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                                        Text(
                                            "Evidence ID: ${job.evidenceId}",
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = Color(0xFF10B981)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
