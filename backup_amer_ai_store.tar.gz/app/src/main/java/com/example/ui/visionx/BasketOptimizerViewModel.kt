package com.example.ui.visionx

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.CartItemEntity
import com.example.data.ProductEntity
import com.example.ui.TrendingProduct
import com.example.data.agent.AgentEngine
import com.example.data.agent.AgentKey
import com.example.data.visionx.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

/**
 * Detailed Source Comparison Model for Basket Optimization
 */
data class BasketSourceComparison(
    val sourceId: String,
    val sourceNameAr: String,
    val sourceNameEn: String,
    val sourceCategory: String,
    val subtotal: Double,
    val deliveryFee: Double,
    val totalCost: Double,
    val etaMinutes: Int,
    val availableItemsCount: Int,
    val totalItemsCount: Int,
    val isBestPrice: Boolean = false,
    val isFastest: Boolean = false,
    val savingsVsCurrent: Double = 0.0
)

/**
 * BasketOptimizerViewModel
 * Handles logic for comparing product prices across different sources (Supermarkets, Wholesale, Farmers Co-op)
 * and generates cost-optimized shopping baskets according to customer objectives.
 */
class BasketOptimizerViewModel : ViewModel() {

    private val _selectedObjective = MutableStateFlow(OptimizationObjective.CHEAPEST)
    val selectedObjective: StateFlow<OptimizationObjective> = _selectedObjective.asStateFlow()

    private val _isOptimizing = MutableStateFlow(false)
    val isOptimizing: StateFlow<Boolean> = _isOptimizing.asStateFlow()

    private val _optimizationResult = MutableStateFlow<BasketOptimizationResult?>(null)
    val optimizationResult: StateFlow<BasketOptimizationResult?> = _optimizationResult.asStateFlow()

    private val _sourceComparisons = MutableStateFlow<List<BasketSourceComparison>>(emptyList())
    val sourceComparisons: StateFlow<List<BasketSourceComparison>> = _sourceComparisons.asStateFlow()

    private val _appliedStatus = MutableStateFlow<String?>(null)
    val appliedStatus: StateFlow<String?> = _appliedStatus.asStateFlow()

    /**
     * Updates the active optimization objective and re-runs basket evaluation
     */
    fun setObjective(objective: OptimizationObjective, currentCart: List<CartItemEntity>) {
        _selectedObjective.value = objective
        optimizeBasket(currentCart, objective)
    }

    /**
     * Updates the active optimization objective and re-runs wishlist items evaluation
     */
    fun setObjectiveForWishlist(objective: OptimizationObjective, wishlistProducts: List<TrendingProduct>) {
        _selectedObjective.value = objective
        optimizeWishlistBasket(wishlistProducts, objective)
    }

    /**
     * Calculates the most cost-effective combination of items across multiple retailers
     * for products saved in a user's wishlist.
     */
    fun optimizeWishlistBasket(
        wishlistProducts: List<TrendingProduct>,
        objective: OptimizationObjective = _selectedObjective.value
    ) {
        if (wishlistProducts.isEmpty()) {
            _optimizationResult.value = null
            _sourceComparisons.value = emptyList()
            return
        }

        val cartEquivalent = wishlistProducts.map { prod ->
            CartItemEntity(
                userId = 0,
                productId = prod.id,
                productName = prod.name,
                imageUrl = prod.imageUrl,
                price = prod.retailPrice,
                quantity = 1,
                orderType = "Retail"
            )
        }

        viewModelScope.launch {
            _isOptimizing.value = true
            try {
                val (result, comparisons) = withContext(Dispatchers.Default) {
                    calculateOptimizationAndComparisons(cartEquivalent, objective)
                }
                _optimizationResult.value = result
                _sourceComparisons.value = comparisons

                // Record immutable evidence in 19-Agent Governance Ledger
                AgentEngine.recordEvidence(
                    operationId = "WISHLIST_OPT_${result.optimizationId}",
                    actorId = AgentKey.FINANCE_UNIT_ECONOMICS.key,
                    type = "WISHLIST_BASKET_COST_OPTIMIZATION",
                    source = "BasketOptimizerViewModel & Multi-Retailer Comparator",
                    payloadSummary = "Optimized ${wishlistProducts.size} wishlist items across retailers. Original: $${String.format("%.2f", result.originalTotal)} -> Optimized: $${String.format("%.2f", result.optimizedTotal)} (Saved: $${String.format("%.2f", result.totalSavings)}). Strategy: ${objective.name}"
                )
            } finally {
                _isOptimizing.value = false
            }
        }
    }

    /**
     * Overload for wishlist optimization using ProductEntity list
     */
    fun optimizeWishlistProducts(
        wishlistProducts: List<ProductEntity>,
        objective: OptimizationObjective = _selectedObjective.value
    ) {
        if (wishlistProducts.isEmpty()) {
            _optimizationResult.value = null
            _sourceComparisons.value = emptyList()
            return
        }

        val cartEquivalent = wishlistProducts.map { prod ->
            CartItemEntity(
                userId = 0,
                productId = prod.id,
                productName = prod.name,
                imageUrl = prod.imageUrl,
                price = prod.retailPrice,
                quantity = 1,
                orderType = "Retail"
            )
        }

        viewModelScope.launch {
            _isOptimizing.value = true
            try {
                val (result, comparisons) = withContext(Dispatchers.Default) {
                    calculateOptimizationAndComparisons(cartEquivalent, objective)
                }
                _optimizationResult.value = result
                _sourceComparisons.value = comparisons

                AgentEngine.recordEvidence(
                    operationId = "WISHLIST_OPT_${result.optimizationId}",
                    actorId = AgentKey.FINANCE_UNIT_ECONOMICS.key,
                    type = "WISHLIST_BASKET_COST_OPTIMIZATION",
                    source = "BasketOptimizerViewModel & Multi-Retailer Comparator",
                    payloadSummary = "Optimized ${wishlistProducts.size} wishlist items across retailers. Original: $${String.format("%.2f", result.originalTotal)} -> Optimized: $${String.format("%.2f", result.optimizedTotal)} (Saved: $${String.format("%.2f", result.totalSavings)}). Strategy: ${objective.name}"
                )
            } finally {
                _isOptimizing.value = false
            }
        }
    }

    /**
     * Compares product prices across different sources and computes optimal store allocations
     */
    fun optimizeBasket(
        cartItems: List<CartItemEntity>,
        objective: OptimizationObjective = _selectedObjective.value
    ) {
        if (cartItems.isEmpty()) {
            _optimizationResult.value = null
            _sourceComparisons.value = emptyList()
            return
        }

        viewModelScope.launch {
            _isOptimizing.value = true
            try {
                val (result, comparisons) = withContext(Dispatchers.Default) {
                    calculateOptimizationAndComparisons(cartItems, objective)
                }
                _optimizationResult.value = result
                _sourceComparisons.value = comparisons

                // Record immutable evidence in 19-Agent Governance Ledger
                AgentEngine.recordEvidence(
                    operationId = "BASKET_OPT_${result.optimizationId}",
                    actorId = AgentKey.FINANCE_UNIT_ECONOMICS.key,
                    type = "BASKET_COST_OPTIMIZATION",
                    source = "BasketOptimizerViewModel & Multi-Source Price Comparator",
                    payloadSummary = "Optimized ${cartItems.size} items. Original: $${String.format("%.2f", result.originalTotal)} -> Optimized: $${String.format("%.2f", result.optimizedTotal)} (Saved: $${String.format("%.2f", result.totalSavings)}). Strategy: ${objective.name}"
                )
            } finally {
                _isOptimizing.value = false
            }
        }
    }

    /**
     * Applies the suggested optimized basket splits and executes callback
     */
    fun applyOptimization(onSuccess: () -> Unit) {
        val current = _optimizationResult.value ?: return
        _optimizationResult.value = current.copy(isApplied = true)
        _appliedStatus.value = "تم تطبيق التوزيع الموفر بنجاح! وفرت $${String.format("%.2f", current.totalSavings)}"

        AgentEngine.recordEvidence(
            operationId = "BASKET_APPLIED_${current.optimizationId}",
            actorId = AgentKey.EXECUTION_AGENT.key,
            type = "BASKET_STRATEGY_ENACTED",
            source = "BasketOptimizerViewModel",
            payloadSummary = "Customer accepted and applied basket optimization with savings $${String.format("%.2f", current.totalSavings)}"
        )
        onSuccess()
    }

    fun dismissStatus() {
        _appliedStatus.value = null
    }

    /**
     * Core price comparison and basket allocation algorithm
     */
    private fun calculateOptimizationAndComparisons(
        cartItems: List<CartItemEntity>,
        objective: OptimizationObjective
    ): Pair<BasketOptimizationResult, List<BasketSourceComparison>> {
        val originalSubtotal = cartItems.sumOf { it.price * it.quantity }
        val originalDelivery = if (originalSubtotal > 0) 2.50 else 0.0
        val originalTotal = originalSubtotal + originalDelivery

        // 1. Source Comparison Generation across real/virtual market sources
        // Source A: أسواق النخبة الهايبرماركت (Hypermarket)
        val hypermarketSubtotal = cartItems.sumOf { (it.price * 0.98) * it.quantity }
        val hypermarketDelivery = 2.00
        val hypermarketTotal = hypermarketSubtotal + hypermarketDelivery

        // Source B: سوق الجملة المركزي (Central Wholesale)
        val wholesaleSubtotal = cartItems.sumOf { (it.price * 0.82) * it.quantity }
        val wholesaleDelivery = 4.00
        val wholesaleTotal = wholesaleSubtotal + wholesaleDelivery

        // Source C: تعاونية المزارعين والمنتجين (Direct Farm Co-op)
        val farmCoopSubtotal = cartItems.sumOf {
            val isFreshOrFood = it.productName.contains("خضار") || it.productName.contains("فواكه") || it.productName.contains("لحم") || it.productName.contains("طماطم") || it.productName.contains("تفاح") || it.productName.contains("عسل")
            val mult = if (isFreshOrFood) 0.78 else 1.05
            (it.price * mult) * it.quantity
        }
        val farmCoopDelivery = 2.50
        val farmCoopTotal = farmCoopSubtotal + farmCoopDelivery

        // Source D: المتاجر السريعة المجاورة (Express 15m Delivery)
        val expressSubtotal = cartItems.sumOf { (it.price * 1.08) * it.quantity }
        val expressDelivery = 1.50
        val expressTotal = expressSubtotal + expressDelivery

        val comparisons = listOf(
            BasketSourceComparison(
                sourceId = "src_wholesale",
                sourceNameAr = "سوق الجملة المركزي",
                sourceNameEn = "Central Wholesale Terminal",
                sourceCategory = "جملة وتوفير ضخم",
                subtotal = wholesaleSubtotal,
                deliveryFee = wholesaleDelivery,
                totalCost = wholesaleTotal,
                etaMinutes = 65,
                availableItemsCount = cartItems.size,
                totalItemsCount = cartItems.size,
                isBestPrice = true,
                isFastest = false,
                savingsVsCurrent = (originalTotal - wholesaleTotal).coerceAtLeast(0.0)
            ),
            BasketSourceComparison(
                sourceId = "src_farm_coop",
                sourceNameAr = "تعاونية المزارع والمنتجين",
                sourceNameEn = "Local Farmers Co-op",
                sourceCategory = "طازج من المزرعة مباشرة",
                subtotal = farmCoopSubtotal,
                deliveryFee = farmCoopDelivery,
                totalCost = farmCoopTotal,
                etaMinutes = 45,
                availableItemsCount = cartItems.size,
                totalItemsCount = cartItems.size,
                isBestPrice = false,
                isFastest = false,
                savingsVsCurrent = (originalTotal - farmCoopTotal).coerceAtLeast(0.0)
            ),
            BasketSourceComparison(
                sourceId = "src_hypermarket",
                sourceNameAr = "أسواق النخبة المركزية",
                sourceNameEn = "Elite Central Hypermarket",
                sourceCategory = "سوبرماركت شامل معتمد",
                subtotal = hypermarketSubtotal,
                deliveryFee = hypermarketDelivery,
                totalCost = hypermarketTotal,
                etaMinutes = 35,
                availableItemsCount = cartItems.size,
                totalItemsCount = cartItems.size,
                isBestPrice = false,
                isFastest = false,
                savingsVsCurrent = (originalTotal - hypermarketTotal).coerceAtLeast(0.0)
            ),
            BasketSourceComparison(
                sourceId = "src_express",
                sourceNameAr = "توصيل إكسبريس الفوري",
                sourceNameEn = "Express Rapid Courier",
                sourceCategory = "توصيل فائق السرعة",
                subtotal = expressSubtotal,
                deliveryFee = expressDelivery,
                totalCost = expressTotal,
                etaMinutes = 18,
                availableItemsCount = cartItems.size,
                totalItemsCount = cartItems.size,
                isBestPrice = false,
                isFastest = true,
                savingsVsCurrent = (originalTotal - expressTotal)
            )
        )

        // 2. Generate Split Allocations based on objective
        val splits: List<OptimizedStoreSplit>
        val finalOptimizedTotal: Double
        val strategyExplanationAr: String
        val strategyExplanationEn: String

        when (objective) {
            OptimizationObjective.CHEAPEST -> {
                // Split between wholesale for pantry/canned and farm co-op for fresh produce
                val freshItems = cartItems.filter { it.productName.contains("خضار") || it.productName.contains("فواكه") || it.productName.contains("طماطم") || it.productName.contains("تفاح") || it.productName.contains("عسل") }
                val groceryItems = cartItems.filter { !freshItems.contains(it) }

                if (freshItems.isNotEmpty() && groceryItems.isNotEmpty()) {
                    val freshSub = freshItems.sumOf { (it.price * 0.78) * it.quantity }
                    val grocerySub = groceryItems.sumOf { (it.price * 0.82) * it.quantity }
                    splits = listOf(
                        OptimizedStoreSplit(
                            storeName = "تعاونية المزارع (طازج)",
                            itemNames = freshItems.map { it.productName },
                            subtotal = freshSub,
                            deliveryFee = 1.50,
                            etaMinutes = 40
                        ),
                        OptimizedStoreSplit(
                            storeName = "سوق الجملة المركزي (مؤن وبقالة)",
                            itemNames = groceryItems.map { it.productName },
                            subtotal = grocerySub,
                            deliveryFee = 2.00,
                            etaMinutes = 60
                        )
                    )
                    finalOptimizedTotal = freshSub + grocerySub + 3.50
                    strategyExplanationAr = "تم تقسيم السلة بين تعاونية المزارعين للمنتجات الطازجة وسوق الجملة للمؤن لتحقيق أقصى توفير ممكن."
                    strategyExplanationEn = "Split fresh produce to farmers co-op and grocery to wholesale terminal for absolute max savings."
                } else {
                    splits = listOf(
                        OptimizedStoreSplit(
                            storeName = "سوق الجملة المركزي",
                            itemNames = cartItems.map { it.productName },
                            subtotal = wholesaleSubtotal,
                            deliveryFee = wholesaleDelivery,
                            etaMinutes = 65
                        )
                    )
                    finalOptimizedTotal = wholesaleTotal
                    strategyExplanationAr = "تم تجميع كامل السلة من سوق الجملة المركزي للحصول على سعر التكلفة المباشر."
                    strategyExplanationEn = "Consolidated full basket into wholesale supplier for direct bulk discounts."
                }
            }
            OptimizationObjective.FASTEST -> {
                splits = listOf(
                    OptimizedStoreSplit(
                        storeName = "مركز إكسبريس الفوري",
                        itemNames = cartItems.map { it.productName },
                        subtotal = expressSubtotal,
                        deliveryFee = expressDelivery,
                        etaMinutes = 18
                    )
                )
                finalOptimizedTotal = expressTotal
                strategyExplanationAr = "تم توجيه السلة إلى أقرب متجر إكسبريس لتصلك خلال أقل من 20 دقيقة."
                strategyExplanationEn = "Routed to closest micro-fulfillment dark store for <20min delivery."
            }
            OptimizationObjective.FEWEST_DELIVERIES -> {
                splits = listOf(
                    OptimizedStoreSplit(
                        storeName = "أسواق النخبة المركزية",
                        itemNames = cartItems.map { it.productName },
                        subtotal = hypermarketSubtotal,
                        deliveryFee = hypermarketDelivery,
                        etaMinutes = 35
                    )
                )
                finalOptimizedTotal = hypermarketTotal
                strategyExplanationAr = "تم اختيار متجر شامل واحد يحتوي جميع أغراضك ليتم شحنها بطلب واحد وتوصيل موحد."
                strategyExplanationEn = "Consolidated into a single certified hypermarket for 1-trip combined dropoff."
            }
            OptimizationObjective.BALANCED -> {
                val balancedSub = cartItems.sumOf { (it.price * 0.88) * it.quantity }
                splits = listOf(
                    OptimizedStoreSplit(
                        storeName = "أسواق النخبة المركزية المعتمدة",
                        itemNames = cartItems.map { it.productName },
                        subtotal = balancedSub,
                        deliveryFee = 2.00,
                        etaMinutes = 28
                    )
                )
                finalOptimizedTotal = balancedSub + 2.00
                strategyExplanationAr = "توازن ذكي: تم اختيار متجر موثوق يوفر خصماً 12% مع سرعة توصيل 28 دقيقة وشحنة واحدة."
                strategyExplanationEn = "Smart balance: 12% discount with 28min speed in a single delivery batch."
            }
        }

        val totalSavings = (originalTotal - finalOptimizedTotal).coerceAtLeast(0.0)

        val result = BasketOptimizationResult(
            optimizationId = "opt_" + UUID.randomUUID().toString().take(8),
            objective = objective,
            originalTotal = originalTotal,
            optimizedTotal = finalOptimizedTotal,
            totalSavings = totalSavings,
            storeSplits = splits,
            strategyExplanationAr = strategyExplanationAr,
            strategyExplanationEn = strategyExplanationEn,
            evidenceId = "EVD_OPT_" + UUID.randomUUID().toString().take(8),
            isApplied = false
        )

        return Pair(result, comparisons)
    }
}
